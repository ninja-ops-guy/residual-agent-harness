"""Revert one reviewed repair in memory; no source files are modified."""
import importlib
import subprocess
import sys
import types
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
import pytest

case, output = sys.argv[1:]

def original(module):
    filename = module.replace('.', '/') + '.py'
    name = module.rsplit('.', 1)[0] + '._review_baseline_' + module.rsplit('.', 1)[1]
    result = types.ModuleType(name)
    result.__package__ = module.rsplit('.', 1)[0]
    sys.modules[name] = result
    source = subprocess.check_output(['git', 'show', 'b127d000:' + filename], text=True)
    exec(compile(source, '<b127d000/' + filename + '>', 'exec'), vars(result))
    return result

runtime = importlib.import_module('residual.factory.runtime')
journal = importlib.import_module('residual.factory.runtime_journal')
sandbox = importlib.import_module('residual.sandbox.subprocess_backend')
prefix = 'tests/test_sandbox_timing_repairs.py::'
if case == 'R1':
    base = original(sandbox.__name__)
    sandbox.run_contained = base.run_contained
    sandbox.run_contained_env = base.run_contained_env
    tests = [prefix + 'DeclaredTimeoutTests']
elif case == 'R2':
    runtime.FactoryRuntime._watch = original(runtime.__name__).FactoryRuntime._watch
    tests = [prefix + 'ContentionBudgetTests::test_watchdog_deadline_during_real_lease_contention',
             prefix + 'WatchdogPollingTests']
elif case == 'R3':
    base = original(runtime.__name__).FactoryRuntime.run
    # Preserve the current module's fixture injection seams. Loading the old
    # method with its original globals would bypass ManagedWorktree/owner
    # substitutions and fail before the intended reap fault was exercised.
    runtime.FactoryRuntime.run = types.FunctionType(
        base.__code__, vars(runtime), base.__name__, base.__defaults__, base.__closure__)
    tests = [prefix + 'PendingReapTests']
elif case == 'R4':
    runtime.FactoryRuntime._lease_denial = original(runtime.__name__).FactoryRuntime._lease_denial
    tests = [prefix + 'ContentionBudgetTests::test_retry_preserves_real_sqlite_diagnostic']
elif case == 'R5':
    base = original(journal.__name__)
    journal.RuntimeJournal._read = base.RuntimeJournal._read
    journal.RuntimeJournal._connect = base.RuntimeJournal._connect
    tests = [prefix + 'ContentionBudgetTests::test_reader_retry_caps_connection_and_query_budget',
             prefix + 'ContentionBudgetTests::test_reader_does_not_retry_non_contention_errors',
             prefix + 'ContentionBudgetTests::test_slow_connection_cannot_start_query_after_reader_deadline']
else:
    raise SystemExit('Unknown repair')
print('REVERSION', case, flush=True)
raise SystemExit(pytest.main([*tests, '-vv', '--tb=short', '--junitxml=' + output]))
